APATHY Android APK v2 (Native Media Controls in Notification Shade & Lock Screen)
================================================================================
Package ID: dev.apathy.player
Site URL:   https://awuro.sergeyhownan.workers.dev/
Update API: https://bot-1795701331-3932-awuro.bothost.tech/api/app/version

Built via GitHub Actions (JDK 17 + Gradle 8.7).
