package dev.apathy.player

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Message
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : AppCompatActivity() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private lateinit var webView: WebView
    private lateinit var updateOverlay: FrameLayout
    private lateinit var updateTitle: TextView
    private lateinit var updateVersionMeta: TextView
    private lateinit var updateChangelog: TextView
    private lateinit var updateProgressBar: ProgressBar
    private lateinit var updateStatusText: TextView
    private lateinit var btnUpdateNow: Button
    private lateinit var btnUpdateBrowser: Button
    private lateinit var btnUpdateLater: Button

    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var activeUpdateInfo: AppUpdateInfo? = null
    private var lastUpdateCheckAt: Long = 0L
    private var isDownloadingUpdate = false

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val callback = filePathCallback
        filePathCallback = null
        if (callback == null) return@registerForActivityResult

        if (result.resultCode != RESULT_OK || result.data == null) {
            callback.onReceiveValue(null)
            return@registerForActivityResult
        }

        val data = result.data!!
        val clip = data.clipData
        val uris: Array<Uri>? = when {
            clip != null && clip.itemCount > 0 -> Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
            data.data != null -> arrayOf(data.data!!)
            else -> null
        }
        callback.onReceiveValue(uris)
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            MediaBridge.latestSnapshot?.let { pushMediaSnapshotToService(it) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = Color.parseColor("#050608")
        window.navigationBarColor = Color.parseColor("#050608")
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        webView = findViewById(R.id.webView)
        updateOverlay = findViewById(R.id.updateOverlay)
        updateTitle = findViewById(R.id.updateTitle)
        updateVersionMeta = findViewById(R.id.updateVersionMeta)
        updateChangelog = findViewById(R.id.updateChangelog)
        updateProgressBar = findViewById(R.id.updateProgressBar)
        updateStatusText = findViewById(R.id.updateStatusText)
        btnUpdateNow = findViewById(R.id.btnUpdateNow)
        btnUpdateBrowser = findViewById(R.id.btnUpdateBrowser)
        btnUpdateLater = findViewById(R.id.btnUpdateLater)

        requestNotificationPermissionIfNeeded()
        setupWebView()
        setupMediaCommandListener()
        setupBackNavigation()
        setupUpdateButtons()

        webView.loadUrl(BuildConfig.SITE_URL)
        checkForAppUpdates(forceCheck = true)
    }

    override fun onResume() {
        super.onResume()
        CookieManager.getInstance().flush()
        if (System.currentTimeMillis() - lastUpdateCheckAt > 10 * 60 * 1000L) {
            checkForAppUpdates(forceCheck = false)
        }
    }

    override fun onPause() {
        // Do NOT call webView.onPause() / pauseTimers() so audio keeps playing with screen off!
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onDestroy() {
        MediaBridge.commandListener = null
        scope.cancel()
        try {
            stopService(Intent(this, AudioKeepAliveService::class.java))
        } catch (_: Exception) {}
        webView.destroy()
        super.onDestroy()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val status = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            if (status != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun setupMediaCommandListener() {
        MediaBridge.commandListener = { action, argMs ->
            val safeAction = action.replace("'", "")
            val js = "window.__apathyMediaCommand && window.__apathyMediaCommand('$safeAction', $argMs);"
            try {
                webView.evaluateJavascript(js, null)
            } catch (_: Exception) {}
        }
    }

    private fun pushMediaSnapshotToService(snap: MediaSnapshot) {
        MediaBridge.latestSnapshot = snap
        val intent = Intent(this, AudioKeepAliveService::class.java).apply {
            action = AudioKeepAliveService.ACTION_UPDATE
            putExtra(AudioKeepAliveService.EXTRA_TITLE, snap.title)
            putExtra(AudioKeepAliveService.EXTRA_ARTIST, snap.artist)
            putExtra(AudioKeepAliveService.EXTRA_ARTWORK, snap.artworkUrl)
            putExtra(AudioKeepAliveService.EXTRA_IS_PLAYING, snap.isPlaying)
            putExtra(AudioKeepAliveService.EXTRA_POSITION_MS, snap.positionMs)
            putExtra(AudioKeepAliveService.EXTRA_DURATION_MS, snap.durationMs)
        }
        try {
            if (snap.isPlaying) {
                ContextCompat.startForegroundService(this, intent)
            } else {
                startService(intent)
            }
        } catch (_: Exception) {
            try {
                ContextCompat.startForegroundService(this, intent)
            } catch (_: Exception) {}
        }
    }

    inner class AndroidMediaJsBridge {
        @JavascriptInterface
        fun updateMediaState(
            title: String?,
            artist: String?,
            artworkUrl: String?,
            isPlaying: Boolean,
            positionMs: Long,
            durationMs: Long
        ) {
            val snap = MediaSnapshot(
                title = title?.takeIf { it.isNotBlank() } ?: "APATHY",
                artist = artist?.takeIf { it.isNotBlank() } ?: "APATHY Music",
                artworkUrl = artworkUrl.orEmpty().trim(),
                isPlaying = isPlaying,
                positionMs = positionMs.coerceAtLeast(0L),
                durationMs = durationMs.coerceAtLeast(0L)
            )
            runOnUiThread {
                pushMediaSnapshotToService(snap)
            }
        }

        @JavascriptInterface
        fun clearMediaState() {
            runOnUiThread {
                MediaBridge.latestSnapshot = null
                try {
                    val stopIntent = Intent(this@MainActivity, AudioKeepAliveService::class.java).apply {
                        action = AudioKeepAliveService.ACTION_STOP
                    }
                    startService(stopIntent)
                } catch (_: Exception) {}
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.setBackgroundColor(Color.parseColor("#050608"))

        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(webView, true)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = false
            displayZoomControls = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = if (isNetworkAvailable()) WebSettings.LOAD_DEFAULT else WebSettings.LOAD_CACHE_ELSE_NETWORK
            userAgentString = "$userAgentString APATHY-APK/${BuildConfig.VERSION_NAME}"
        }

        webView.addJavascriptInterface(AndroidMediaJsBridge(), "ApathyAndroid")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                return handlePossibleExternalUri(uri)
            }

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                if (url.isNullOrBlank()) return false
                return handlePossibleExternalUri(Uri.parse(url))
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback

                val acceptTypes = params?.acceptTypes?.filter { it.isNotBlank() } ?: emptyList()
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = when {
                        acceptTypes.any { it.startsWith("image/") } -> "image/*"
                        acceptTypes.any { it.startsWith("audio/") || it.contains("mp3") || it.contains("m4a") } -> "audio/*"
                        else -> "*/*"
                    }
                    if (params?.mode == FileChooserParams.MODE_OPEN_MULTIPLE) {
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    }
                }
                return try {
                    fileChooserLauncher.launch(Intent.createChooser(intent, "Выберите файл"))
                    true
                } catch (_: Exception) {
                    filePathCallback = null
                    false
                }
            }

            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message?
            ): Boolean {
                val tempWebView = WebView(this@MainActivity)
                tempWebView.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView?, req: WebResourceRequest?): Boolean {
                        val target = req?.url ?: return true
                        openExternalUri(target)
                        tempWebView.destroy()
                        return true
                    }

                    @Deprecated("Deprecated in Java")
                    override fun shouldOverrideUrlLoading(v: WebView?, url: String?): Boolean {
                        if (!url.isNullOrBlank()) openExternalUri(Uri.parse(url))
                        tempWebView.destroy()
                        return true
                    }
                }
                val transport = resultMsg?.obj as? WebView.WebViewTransport ?: return false
                transport.webView = tempWebView
                resultMsg.sendToTarget()
                return true
            }
        }
    }

    private fun handlePossibleExternalUri(uri: Uri): Boolean {
        val scheme = uri.scheme?.lowercase() ?: return false
        if (scheme == "tg" || scheme == "mailto" || scheme == "tel" || scheme == "intent") {
            openExternalUri(uri)
            return true
        }
        val host = uri.host?.lowercase() ?: return false
        val siteHost = Uri.parse(BuildConfig.SITE_URL).host?.lowercase().orEmpty()
        val botHost = Uri.parse(BuildConfig.BOT_API_URL).host?.lowercase().orEmpty()
        if (host == siteHost || host == botHost || host.endsWith(".workers.dev")) {
            return false
        }
        openExternalUri(uri)
        return true
    }

    private fun openExternalUri(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {}
    }

    private fun isNetworkAvailable(): Boolean {
        return try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val active = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(active) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (_: Exception) {
            true
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (updateOverlay.visibility == View.VISIBLE) {
                    if (activeUpdateInfo?.forceUpdate != true && !isDownloadingUpdate) {
                        updateOverlay.visibility = View.GONE
                    }
                    return
                }
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    moveTaskToBack(true)
                }
            }
        })
    }

    private fun setupUpdateButtons() {
        btnUpdateNow.setOnClickListener {
            val info = activeUpdateInfo ?: return@setOnClickListener
            if (!isDownloadingUpdate) startInAppApkDownload(info)
        }
        btnUpdateBrowser.setOnClickListener {
            val info = activeUpdateInfo ?: return@setOnClickListener
            openExternalUri(Uri.parse(info.downloadUrl))
        }
        btnUpdateLater.setOnClickListener {
            if (activeUpdateInfo?.forceUpdate != true && !isDownloadingUpdate) {
                updateOverlay.visibility = View.GONE
            }
        }
    }

    private fun checkForAppUpdates(forceCheck: Boolean) {
        if (!forceCheck && System.currentTimeMillis() - lastUpdateCheckAt < 60_000L) return
        lastUpdateCheckAt = System.currentTimeMillis()
        scope.launch {
            val info = UpdateChecker.fetchUpdateInfo(BuildConfig.BOT_API_URL) ?: return@launch
            if (info.latestVersionCode > BuildConfig.VERSION_CODE) {
                activeUpdateInfo = info
                showUpdateOverlay(info)
            }
        }
    }

    private fun showUpdateOverlay(info: AppUpdateInfo) {
        updateTitle.text = if (info.forceUpdate) "Требуется обновление APATHY" else "Доступно обновление APATHY"
        updateVersionMeta.text = "Текущая: v${BuildConfig.VERSION_NAME} (c${BuildConfig.VERSION_CODE}) → Новая: v${info.latestVersionName} (c${info.latestVersionCode})"
        updateChangelog.text = info.changelog
        btnUpdateLater.visibility = if (info.forceUpdate) View.GONE else View.VISIBLE
        updateProgressBar.visibility = View.GONE
        updateStatusText.visibility = View.GONE
        btnUpdateNow.isEnabled = true
        updateOverlay.visibility = View.VISIBLE
    }

    private fun startInAppApkDownload(info: AppUpdateInfo) {
        isDownloadingUpdate = true
        btnUpdateNow.isEnabled = false
        updateProgressBar.visibility = View.VISIBLE
        updateProgressBar.progress = 0
        updateStatusText.visibility = View.VISIBLE
        updateStatusText.text = "Загрузка обновления..."

        scope.launch {
            val apkFile = UpdateChecker.downloadApk(this@MainActivity, info.downloadUrl) { pct ->
                updateProgressBar.progress = pct
                updateStatusText.text = "Загрузка: $pct%"
            }
            isDownloadingUpdate = false
            btnUpdateNow.isEnabled = true
            if (apkFile != null) {
                updateStatusText.text = "Запуск установщика..."
                installDownloadedApk(apkFile)
            } else {
                updateStatusText.text = "Не удалось скачать автоматически. Нажмите «Скачать в браузере»."
            }
        }
    }

    private fun installDownloadedApk(apkFile: File) {
        try {
            val apkUri = FileProvider.getUriForFile(
                this,
                "${BuildConfig.APPLICATION_ID}.fileprovider",
                apkFile
            )
            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(apkUri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(installIntent)
        } catch (_: Exception) {
            activeUpdateInfo?.let { openExternalUri(Uri.parse(it.downloadUrl)) }
        }
    }
}
