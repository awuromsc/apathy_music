package dev.apathy.player

import android.os.Handler
import android.os.Looper

data class MediaSnapshot(
    val title: String = "APATHY",
    val artist: String = "APATHY Music",
    val artworkUrl: String = "",
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L
)

object MediaBridge {
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    var latestSnapshot: MediaSnapshot? = null

    @Volatile
    var commandListener: ((action: String, argMs: Long) -> Unit)? = null

    fun dispatchCommand(action: String, argMs: Long = 0L) {
        mainHandler.post {
            commandListener?.invoke(action, argMs)
        }
    }
}
