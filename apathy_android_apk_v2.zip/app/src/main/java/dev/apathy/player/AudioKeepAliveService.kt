package dev.apathy.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.media.app.NotificationCompat.MediaStyle
import androidx.media.session.MediaButtonReceiver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

class AudioKeepAliveService : Service() {

    companion object {
        const val CHANNEL_ID = "apathy_media_playback"
        const val NOTIF_ID = 4201

        const val ACTION_UPDATE = "dev.apathy.player.ACTION_UPDATE"
        const val ACTION_PLAY = "dev.apathy.player.ACTION_PLAY"
        const val ACTION_PAUSE = "dev.apathy.player.ACTION_PAUSE"
        const val ACTION_TOGGLE = "dev.apathy.player.ACTION_TOGGLE"
        const val ACTION_NEXT = "dev.apathy.player.ACTION_NEXT"
        const val ACTION_PREV = "dev.apathy.player.ACTION_PREV"
        const val ACTION_STOP = "dev.apathy.player.ACTION_STOP"

        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_ARTIST = "extra_artist"
        const val EXTRA_ARTWORK = "extra_artwork"
        const val EXTRA_IS_PLAYING = "extra_is_playing"
        const val EXTRA_POSITION_MS = "extra_position_ms"
        const val EXTRA_DURATION_MS = "extra_duration_ms"
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var mediaSession: MediaSessionCompat
    private lateinit var notificationManager: NotificationManager

    private var defaultArtwork: Bitmap? = null
    private var cachedArtworkUrl: String = ""
    private var cachedArtworkBitmap: Bitmap? = null
    private var artworkLoadJob: Job? = null
    private var isInForeground = false
    private var currentSnapshot: MediaSnapshot = MediaSnapshot()

    private val becomingNoisyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) {
                if (currentSnapshot.isPlaying) {
                    MediaBridge.dispatchCommand("pause")
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createNotificationChannel()

        defaultArtwork = try {
            BitmapFactory.decodeResource(resources, R.mipmap.ic_launcher)
        } catch (_: Exception) {
            null
        }

        mediaSession = MediaSessionCompat(this, "APATHY_MEDIA_SESSION").apply {
            setCallback(object : MediaSessionCompat.Callback() {
                override fun onPlay() {
                    MediaBridge.dispatchCommand("play")
                }

                override fun onPause() {
                    MediaBridge.dispatchCommand("pause")
                }

                override fun onSkipToNext() {
                    MediaBridge.dispatchCommand("next")
                }

                override fun onSkipToPrevious() {
                    MediaBridge.dispatchCommand("prev")
                }

                override fun onSeekTo(pos: Long) {
                    MediaBridge.dispatchCommand("seek", pos)
                }

                override fun onStop() {
                    MediaBridge.dispatchCommand("stop")
                }
            })
            isActive = true
        }

        try {
            ContextCompat.registerReceiver(
                this,
                becomingNoisyReceiver,
                IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
        } catch (_: Exception) {}
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            MediaBridge.latestSnapshot?.let { applySnapshot(it) }
            return START_NOT_STICKY
        }

        if (Intent.ACTION_MEDIA_BUTTON == intent.action) {
            MediaButtonReceiver.handleIntent(mediaSession, intent)
            return START_NOT_STICKY
        }

        when (intent.action) {
            ACTION_UPDATE -> {
                val snap = MediaSnapshot(
                    title = intent.getStringExtra(EXTRA_TITLE)?.takeIf { it.isNotBlank() } ?: "APATHY",
                    artist = intent.getStringExtra(EXTRA_ARTIST)?.takeIf { it.isNotBlank() } ?: "APATHY Music",
                    artworkUrl = intent.getStringExtra(EXTRA_ARTWORK).orEmpty(),
                    isPlaying = intent.getBooleanExtra(EXTRA_IS_PLAYING, false),
                    positionMs = intent.getLongExtra(EXTRA_POSITION_MS, 0L).coerceAtLeast(0L),
                    durationMs = intent.getLongExtra(EXTRA_DURATION_MS, 0L).coerceAtLeast(0L)
                )
                applySnapshot(snap)
            }
            ACTION_PLAY -> {
                MediaBridge.dispatchCommand("play")
            }
            ACTION_PAUSE -> {
                MediaBridge.dispatchCommand("pause")
            }
            ACTION_TOGGLE -> {
                MediaBridge.dispatchCommand("toggle")
            }
            ACTION_NEXT -> {
                MediaBridge.dispatchCommand("next")
            }
            ACTION_PREV -> {
                MediaBridge.dispatchCommand("prev")
            }
            ACTION_STOP -> {
                MediaBridge.dispatchCommand("stop")
                stopPlaybackForeground(removeNotification = true)
                stopSelf()
            }
            else -> {
                MediaBridge.latestSnapshot?.let { applySnapshot(it) }
            }
        }

        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        stopPlaybackForeground(removeNotification = true)
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        artworkLoadJob?.cancel()
        serviceScope.cancel()
        try {
            unregisterReceiver(becomingNoisyReceiver)
        } catch (_: Exception) {}
        try {
            mediaSession.isActive = false
            mediaSession.release()
        } catch (_: Exception) {}
        stopPlaybackForeground(removeNotification = true)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun applySnapshot(snap: MediaSnapshot) {
        currentSnapshot = snap
        MediaBridge.latestSnapshot = snap

        val artForNow = if (snap.artworkUrl.isNotBlank() && snap.artworkUrl == cachedArtworkUrl && cachedArtworkBitmap != null) {
            cachedArtworkBitmap
        } else {
            defaultArtwork
        }

        updateMediaSessionState(snap, artForNow)
        postNotification(snap, artForNow)

        if (snap.artworkUrl.isNotBlank() && snap.artworkUrl != cachedArtworkUrl) {
            loadArtworkAsync(snap.artworkUrl)
        } else if (snap.artworkUrl.isBlank()) {
            artworkLoadJob?.cancel()
            cachedArtworkUrl = ""
            cachedArtworkBitmap = null
        }
    }

    private fun loadArtworkAsync(url: String) {
        artworkLoadJob?.cancel()
        artworkLoadJob = serviceScope.launch {
            val bmp = withContext(Dispatchers.IO) { downloadBitmap(url) }
            if (bmp != null && currentSnapshot.artworkUrl == url) {
                cachedArtworkUrl = url
                cachedArtworkBitmap = bmp
                updateMediaSessionState(currentSnapshot, bmp)
                postNotification(currentSnapshot, bmp)
            }
        }
    }

    private fun downloadBitmap(rawUrl: String): Bitmap? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(rawUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 6000
                readTimeout = 6000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "APATHY-APK/${BuildConfig.VERSION_NAME}")
            }
            if (conn.responseCode in 200..299) {
                conn.inputStream.use { stream ->
                    val decoded = BitmapFactory.decodeStream(stream) ?: return null
                    scaleBitmapIfNeeded(decoded, 512)
                }
            } else {
                null
            }
        } catch (_: Exception) {
            null
        } finally {
            try { conn?.disconnect() } catch (_: Exception) {}
        }
    }

    private fun scaleBitmapIfNeeded(src: Bitmap, maxDim: Int): Bitmap {
        val w = src.width
        val h = src.height
        if (w <= maxDim && h <= maxDim) return src
        val ratio = minOf(maxDim.toFloat() / w.toFloat(), maxDim.toFloat() / h.toFloat())
        val nw = (w * ratio).toInt().coerceAtLeast(1)
        val nh = (h * ratio).toInt().coerceAtLeast(1)
        return try {
            Bitmap.createScaledBitmap(src, nw, nh, true)
        } catch (_: Exception) {
            src
        }
    }

    private fun updateMediaSessionState(snap: MediaSnapshot, art: Bitmap?) {
        val metadataBuilder = MediaMetadataCompat.Builder()
            .putString(MediaMetadataCompat.METADATA_KEY_TITLE, snap.title)
            .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, snap.artist)
            .putString(MediaMetadataCompat.METADATA_KEY_ALBUM, "APATHY")
            .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, snap.durationMs)

        if (art != null) {
            metadataBuilder.putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, art)
            metadataBuilder.putBitmap(MediaMetadataCompat.METADATA_KEY_DISPLAY_ICON, art)
        }
        mediaSession.setMetadata(metadataBuilder.build())

        val actions = PlaybackStateCompat.ACTION_PLAY or
            PlaybackStateCompat.ACTION_PAUSE or
            PlaybackStateCompat.ACTION_PLAY_PAUSE or
            PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
            PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or
            PlaybackStateCompat.ACTION_SEEK_TO or
            PlaybackStateCompat.ACTION_STOP

        val stateCode = if (snap.isPlaying) {
            PlaybackStateCompat.STATE_PLAYING
        } else {
            PlaybackStateCompat.STATE_PAUSED
        }
        val speed = if (snap.isPlaying) 1.0f else 0.0f

        val playbackState = PlaybackStateCompat.Builder()
            .setActions(actions)
            .setState(stateCode, snap.positionMs, speed, SystemClock.elapsedRealtime())
            .build()

        mediaSession.setPlaybackState(playbackState)
        if (!mediaSession.isActive) mediaSession.isActive = true
    }

    private fun buildNotification(snap: MediaSnapshot, art: Bitmap?): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPi = PendingIntent.getActivity(
            this,
            100,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val prevPi = servicePendingIntent(ACTION_PREV, 101)
        val playPauseAction = if (snap.isPlaying) ACTION_PAUSE else ACTION_PLAY
        val playPausePi = servicePendingIntent(playPauseAction, 102)
        val nextPi = servicePendingIntent(ACTION_NEXT, 103)

        val playPauseIcon = if (snap.isPlaying) R.drawable.ic_media_pause else R.drawable.ic_media_play
        val playPauseTitle = if (snap.isPlaying) "Пауза" else "Воспроизвести"

        val mediaStyle = MediaStyle()
            .setMediaSession(mediaSession.sessionToken)
            .setShowActionsInCompactView(0, 1, 2)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_apathy)
            .setLargeIcon(art)
            .setContentTitle(snap.title)
            .setContentText(snap.artist)
            .setSubText("APATHY")
            .setContentIntent(contentPi)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setShowWhen(false)
            .setOngoing(snap.isPlaying)
            .addAction(R.drawable.ic_media_prev, "Предыдущий", prevPi)
            .addAction(playPauseIcon, playPauseTitle, playPausePi)
            .addAction(R.drawable.ic_media_next, "Следующий", nextPi)
            .setStyle(mediaStyle)
            .build()
    }

    private fun postNotification(snap: MediaSnapshot, art: Bitmap?) {
        val notification = buildNotification(snap, art)
        try {
            if (snap.isPlaying) {
                val fgType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                } else {
                    0
                }
                ServiceCompat.startForeground(this, NOTIF_ID, notification, fgType)
                isInForeground = true
            } else {
                if (!isInForeground) {
                    val fgType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                    } else {
                        0
                    }
                    ServiceCompat.startForeground(this, NOTIF_ID, notification, fgType)
                    isInForeground = true
                }
                ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_DETACH)
                isInForeground = false
                notificationManager.notify(NOTIF_ID, notification)
            }
        } catch (_: Exception) {
            try {
                notificationManager.notify(NOTIF_ID, notification)
            } catch (_: Exception) {}
        }
    }

    private fun stopPlaybackForeground(removeNotification: Boolean) {
        try {
            if (removeNotification) {
                ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
                notificationManager.cancel(NOTIF_ID)
            } else {
                ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_DETACH)
            }
        } catch (_: Exception) {}
        isInForeground = false
    }

    private fun servicePendingIntent(action: String, reqCode: Int): PendingIntent {
        val i = Intent(this, AudioKeepAliveService::class.java).setAction(action)
        return PendingIntent.getService(
            this,
            reqCode,
            i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Воспроизведение APATHY",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Управление музыкой на шторке и экране блокировки"
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            notificationManager.createNotificationChannel(channel)
        }
    }
}
