package dev.apathy.player

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

data class AppUpdateInfo(
    val latestVersionCode: Int,
    val latestVersionName: String,
    val minSupportedVersionCode: Int,
    val forceUpdate: Boolean,
    val downloadUrl: String,
    val changelog: String
)

object UpdateChecker {

    suspend fun fetchUpdateInfo(botApiBaseUrl: String): AppUpdateInfo? = withContext(Dispatchers.IO) {
        var conn: HttpURLConnection? = null
        try {
            val cleanBase = botApiBaseUrl.trimEnd('/')
            val url = URL("$cleanBase/api/app/version?t=${System.currentTimeMillis()}")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "APATHY-APK/${BuildConfig.VERSION_NAME}")
            }
            if (conn.responseCode !in 200..299) return@withContext null
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(body)

            val latestCode = when {
                json.has("latestVersionCode") -> json.optInt("latestVersionCode", 0)
                json.has("versionCode") -> json.optInt("versionCode", 0)
                json.has("version_code") -> json.optInt("version_code", 0)
                else -> 0
            }
            if (latestCode <= 0) return@withContext null

            val latestName = json.optString("latestVersionName")
                .ifBlank { json.optString("versionName") }
                .ifBlank { json.optString("version_name") }
                .ifBlank { "v$latestCode" }

            val minCode = when {
                json.has("minSupportedVersionCode") -> json.optInt("minSupportedVersionCode", 0)
                json.has("minVersionCode") -> json.optInt("minVersionCode", 0)
                json.has("min_version_code") -> json.optInt("min_version_code", 0)
                else -> 0
            }

            val force = json.optBoolean("forceUpdate", false) ||
                json.optBoolean("force_update", false) ||
                json.optBoolean("force", false) ||
                (minCode > BuildConfig.VERSION_CODE)

            var dlUrl = json.optString("downloadUrl")
                .ifBlank { json.optString("apkUrl") }
                .ifBlank { json.optString("apk_url") }
                .ifBlank { json.optString("download_url") }

            if (dlUrl.startsWith("/")) {
                dlUrl = cleanBase + dlUrl
            }
            if (dlUrl.isBlank()) {
                dlUrl = "$cleanBase/api/app/apk"
            }

            val notes = json.optString("changelog")
                .ifBlank { json.optString("notes") }
                .ifBlank { json.optString("message") }
                .ifBlank { "Улучшена стабильность и добавлены новые функции." }

            AppUpdateInfo(
                latestVersionCode = latestCode,
                latestVersionName = latestName,
                minSupportedVersionCode = minCode,
                forceUpdate = force,
                downloadUrl = dlUrl,
                changelog = notes
            )
        } catch (_: Exception) {
            null
        } finally {
            try { conn?.disconnect() } catch (_: Exception) {}
        }
    }

    suspend fun downloadApk(
        context: Context,
        downloadUrl: String,
        onProgress: (percent: Int) -> Unit
    ): File? = withContext(Dispatchers.IO) {
        var conn: HttpURLConnection? = null
        try {
            val updatesDir = File(context.cacheDir, "updates").apply { mkdirs() }
            val outFile = File(updatesDir, "apathy-update.apk")
            if (outFile.exists()) outFile.delete()

            conn = (URL(downloadUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 15000
                readTimeout = 30000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "APATHY-APK/${BuildConfig.VERSION_NAME}")
            }
            if (conn.responseCode !in 200..299) return@withContext null

            val totalBytes = conn.contentLengthLong
            var downloaded = 0L
            var lastPct = -1

            conn.inputStream.use { input ->
                FileOutputStream(outFile).use { output ->
                    val buf = ByteArray(16 * 1024)
                    while (true) {
                        val read = input.read(buf)
                        if (read <= 0) break
                        output.write(buf, 0, read)
                        downloaded += read
                        if (totalBytes > 0) {
                            val pct = ((downloaded * 100L) / totalBytes).toInt().coerceIn(0, 100)
                            if (pct != lastPct) {
                                lastPct = pct
                                withContext(Dispatchers.Main) { onProgress(pct) }
                            }
                        }
                    }
                    output.flush()
                }
            }

            if (outFile.exists() && outFile.length() > 100_000L) outFile else null
        } catch (_: Exception) {
            null
        } finally {
            try { conn?.disconnect() } catch (_: Exception) {}
        }
    }
}
