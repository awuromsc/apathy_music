plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val envVersionCode = System.getenv("APATHY_VERSION_CODE")?.toIntOrNull() ?: 2
val envVersionName = System.getenv("APATHY_VERSION_NAME")?.takeIf { it.isNotBlank() } ?: "1.1.0"
val envKeystorePath = System.getenv("KEYSTORE_PATH") ?: ""
val envKeystorePass = System.getenv("KEYSTORE_PASSWORD")?.takeIf { it.isNotBlank() } ?: "apathy2026"
val envKeyAlias = System.getenv("KEY_ALIAS")?.takeIf { it.isNotBlank() } ?: "apathy"
val envKeyPass = System.getenv("KEY_PASSWORD")?.takeIf { it.isNotBlank() } ?: "apathy2026"

android {
    namespace = "dev.apathy.player"
    compileSdk = 34

    defaultConfig {
        applicationId = "dev.apathy.player"
        minSdk = 24
        targetSdk = 34
        versionCode = envVersionCode
        versionName = envVersionName

        buildConfigField("String", "SITE_URL", "\"https://awuro.sergeyhownan.workers.dev/\"")
        buildConfigField("String", "BOT_API_URL", "\"https://bot-1795701331-3932-awuro.bothost.tech\"")
    }

    signingConfigs {
        create("release") {
            if (envKeystorePath.isNotBlank() && file(envKeystorePath).exists()) {
                storeFile = file(envKeystorePath)
                storePassword = envKeystorePass
                keyAlias = envKeyAlias
                keyPassword = envKeyPass
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            if (envKeystorePath.isNotBlank() && file(envKeystorePath).exists()) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("androidx.media:media:1.7.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
