plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val envVersionCode = System.getenv("APATHY_VERSION_CODE")?.toIntOrNull() ?: 1
val envVersionName = System.getenv("APATHY_VERSION_NAME")?.takeIf { it.isNotBlank() } ?: "1.0.0"

android {
    namespace = "dev.apathy.player"
    compileSdk = 34

    defaultConfig {
        applicationId = "dev.apathy.player"
        minSdk = 24
        targetSdk = 34
        versionCode = envVersionCode
        versionName = envVersionName

        buildConfigField("String", "SITE_URL", "\"https://awuro.sergeyhownan.workers.dev/\"")
        buildConfigField("String", "VERSION_API_URL", "\"https://bot-1795701331-3932-awuro.bothost.tech/api/app/version\"")
    }

    signingConfigs {
        create("release") {
            val ksPath = System.getenv("KEYSTORE_PATH") ?: "${rootDir}/apathy-release.jks"
            val ksFile = file(ksPath)
            if (ksFile.exists()) {
                storeFile = ksFile
                storePassword = System.getenv("KEYSTORE_PASSWORD") ?: "apathy2026"
                keyAlias = System.getenv("KEY_ALIAS") ?: "apathy"
                keyPassword = System.getenv("KEY_PASSWORD") ?: "apathy2026"
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            val relConfig = signingConfigs.findByName("release")
            if (relConfig?.storeFile?.exists() == true) {
                signingConfig = relConfig
            }
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isDebuggable = true
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
