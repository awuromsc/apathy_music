package dev.apathy.player

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Message
import android.provider.Settings
import android.view.View
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var updateOverlay: FrameLayout
    private lateinit var updateTitle: TextView
    private lateinit var updateVersionMeta: TextView
    private lateinit var updateChangelog: TextView
    private lateinit var updateProgressBar: ProgressBar
    private lateinit var updateStatusText: TextView
    private lateinit var btnUpdateNow: Button
    private lateinit var btnUpdateBrowser: Button
    private lateinit var btnUpdateLater: Button

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var lastUpdateCheckAt = 0L
    private var isForceBlocked = false
    private var activeUpdateInfo: AppVersionInfo? = null
    private var isDownloadingUpdate = false

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val cb = filePathCallback
        filePathCallback = null
        if (cb == null) return@registerForActivityResult

        if (result.resultCode != Activity.RESULT_OK || result.data == null) {
            cb.onReceiveValue(null)
            return@registerForActivityResult
        }

        val data = result.data!!
        val uris = mutableListOf<Uri>()
        val clip = data.clipData
        if (clip != null && clip.itemCount > 0) {
            for (i in 0 until clip.itemCount) {
                clip.getItemAt(i)?.uri?.let { uris.add(it) }
            }
        } else {
            data.data?.let { uris.add(it) }
        }
        cb.onReceiveValue(if (uris.isNotEmpty()) uris.toTypedArray() else null)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        window.statusBarColor = Color.parseColor("#050608")
        window.navigationBarColor = Color.parseColor("#050608")
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        webView = findViewById(R.id.webView)
        updateOverlay = findViewById(R.id.updateOverlay)
        updateTitle = findViewById(R.id.updateTitle)
        updateVersionMeta = findViewById(R.id.updateVersionMeta)
        updateChangelog = findViewById(R.id.updateChangelog)
        updateProgressBar = findViewById(R.id.updateProgressBar)
        updateStatusText = findViewById(R.id.updateStatusText)
        btnUpdateNow = findViewById(R.id.btnUpdateNow)
        btnUpdateBrowser = findViewById(R.id.btnUpdateBrowser)
        btnUpdateLater = findViewById(R.id.btnUpdateLater)

        setupWebView()
        setupBackNavigation()
        setupUpdateButtons()
        startKeepAliveService()

        webView.loadUrl(BuildConfig.SITE_URL)
        checkForAppUpdates(forceCheck = true)
    }

    override fun onResume() {
        super.onResume()
        CookieManager.getInstance().flush()
        if (System.currentTimeMillis() - lastUpdateCheckAt > 10 * 60 * 1000L) {
            checkForAppUpdates(forceCheck = false)
        }
    }

    override fun onPause() {
        // Deliberately DO NOT call webView.onPause() / pauseTimers() so music continues playing with screen off!
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onDestroy() {
        scope.cancel()
        try {
            stopService(Intent(this, AudioKeepAliveService::class.java))
        } catch (_: Exception) {}
        webView.destroy()
        super.onDestroy()
    }

    private fun startKeepAliveService() {
        try {
            val svc = Intent(this, AudioKeepAliveService::class.java)
            ContextCompat.startForegroundService(this, svc)
        } catch (_: Exception) {
            // Safe fallback if notification permission not granted on Android 13+
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.setBackgroundColor(Color.parseColor("#050608"))

        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(webView, true)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = false
            displayZoomControls = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = if (isNetworkAvailable()) WebSettings.LOAD_DEFAULT else WebSettings.LOAD_CACHE_ELSE_NETWORK
            userAgentString = "$userAgentString APATHY-APK/${BuildConfig.VERSION_NAME}"
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                return handlePossibleExternalUri(uri)
            }

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                if (url.isNullOrBlank()) return false
                return handlePossibleExternalUri(Uri.parse(url))
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback

                val acceptTypes = params?.acceptTypes?.filter { it.isNotBlank() } ?: emptyList()
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = when {
                        acceptTypes.any { it.startsWith("image/") } -> "image/*"
                        acceptTypes.any { it.startsWith("audio/") || it.contains("mp3") || it.contains("m4a") } -> "audio/*"
                        else -> "*/*"
                    }
                    if (params?.mode == FileChooserParams.MODE_OPEN_MULTIPLE) {
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    }
                }
                return try {
                    fileChooserLauncher.launch(Intent.createChooser(intent, "Выберите файл"))
                    true
                } catch (_: Exception) {
                    filePathCallback = null
                    false
                }
            }

            // Handles window.open("https://t.me/...", "_blank") used by Telegram 1-tap login!
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message?
            ): Boolean {
                val transport = resultMsg?.obj as? WebView.WebViewTransport ?: return false
                val tempWeb = WebView(this@MainActivity)
                tempWeb.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(w: WebView?, req: WebResourceRequest?): Boolean {
                        req?.url?.let { openExternalUri(it) }
                        w?.destroy()
                        return true
                    }

                    @Deprecated("Deprecated in Java")
                    override fun shouldOverrideUrlLoading(w: WebView?, url: String?): Boolean {
                        if (!url.isNullOrBlank()) openExternalUri(Uri.parse(url))
                        w?.destroy()
                        return true
                    }
                }
                transport.webView = tempWeb
                resultMsg.sendToTarget()
                return true
            }
        }
    }

    private fun handlePossibleExternalUri(uri: Uri): Boolean {
        val scheme = (uri.scheme ?: "").lowercase()
        val host = (uri.host ?: "").lowercase()

        if (scheme == "tg" || scheme == "intent" || host == "t.me" || host == "telegram.me" || host.endsWith(".t.me")) {
            openExternalUri(uri)
            return true
        }
        // Keep APATHY site & API inside WebView
        if (host.endsWith("workers.dev") || host.endsWith("bothost.tech")) {
            return false
        }
        if (scheme == "http" || scheme == "https") {
            openExternalUri(uri)
            return true
        }
        return false
    }

    private fun openExternalUri(uri: Uri) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "Не найдено приложение для открытия ссылки", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (isForceBlocked) {
                    // Force update active: allow minimizing, never dismiss the gate
                    moveTaskToBack(true)
                    return
                }
                if (updateOverlay.visibility == View.VISIBLE) {
                    updateOverlay.visibility = View.GONE
                    return
                }
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    // Minimize instead of finishing so audio continues playing seamlessly!
                    moveTaskToBack(true)
                }
            }
        })
    }

    private fun isNetworkAvailable(): Boolean {
        return try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val net = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(net) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (_: Exception) {
            true
        }
    }

    // ==================== FORCE / OPTIONAL UPDATE ENGINE ====================
    private fun checkForAppUpdates(forceCheck: Boolean) {
        if (!isNetworkAvailable()) return
        if (!forceCheck && isForceBlocked) return
        lastUpdateCheckAt = System.currentTimeMillis()

        scope.launch {
            val info = UpdateChecker.fetchVersionInfo(BuildConfig.VERSION_API_URL) ?: return@launch
            if (info.apkUrl.isBlank()) return@launch

            val currentCode = BuildConfig.VERSION_CODE
            val mustUpdate = currentCode < info.minVersionCode || (info.force && currentCode < info.latestVersionCode)
            val hasOptional = currentCode < info.latestVersionCode

            if (mustUpdate || hasOptional) {
                showUpdateOverlay(info, isForce = mustUpdate)
            }
        }
    }

    private fun showUpdateOverlay(info: AppVersionInfo, isForce: Boolean) {
        activeUpdateInfo = info
        isForceBlocked = isForce

        updateTitle.text = if (isForce) "Требуется обновление" else "Доступна новая версия"
        updateVersionMeta.text = "Текущая: v${BuildConfig.VERSION_NAME}  →  Новая: v${info.latestVersionName}"
        updateChangelog.text = info.changelog.ifBlank { "Новые функции и улучшения стабильности APATHY." }

        updateProgressBar.visibility = View.GONE
        updateProgressBar.progress = 0
        updateStatusText.visibility = View.GONE
        btnUpdateNow.isEnabled = true
        btnUpdateNow.text = "Скачать и обновить"
        btnUpdateBrowser.visibility = View.GONE
        btnUpdateLater.visibility = if (isForce) View.GONE else View.VISIBLE

        updateOverlay.visibility = View.VISIBLE
    }

    private fun setupUpdateButtons() {
        btnUpdateLater.setOnClickListener {
            if (!isForceBlocked && !isDownloadingUpdate) {
                updateOverlay.visibility = View.GONE
            }
        }

        btnUpdateBrowser.setOnClickListener {
            val url = activeUpdateInfo?.apkUrl ?: return@setOnClickListener
            openExternalUri(Uri.parse(url))
        }

        btnUpdateNow.setOnClickListener {
            val info = activeUpdateInfo ?: return@setOnClickListener
            if (isDownloadingUpdate) return@setOnClickListener

            // On Android 8+, check "Install unknown apps" permission first
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
                Toast.makeText(
                    this,
                    "Разрешите установку обновлений для APATHY и вернитесь назад",
                    Toast.LENGTH_LONG
                ).show()
                try {
                    val permIntent = Intent(
                        Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(permIntent)
                } catch (_: Exception) {
                    openExternalUri(Uri.parse(info.apkUrl))
                }
                return@setOnClickListener
            }

            startInAppApkDownload(info)
        }
    }

    private fun startInAppApkDownload(info: AppVersionInfo) {
        isDownloadingUpdate = true
        btnUpdateNow.isEnabled = false
        btnUpdateNow.text = "Загрузка..."
        updateProgressBar.visibility = View.VISIBLE
        updateProgressBar.progress = 0
        updateStatusText.visibility = View.VISIBLE
        updateStatusText.text = "Скачивание APATHY v${info.latestVersionName}..."

        scope.launch {
            val outFile = File(cacheDir, "apathy_update.apk")
            val ok = UpdateChecker.downloadApk(info.apkUrl, outFile) { pct ->
                updateProgressBar.progress = pct
                updateStatusText.text = "Загружено: $pct%"
            }
            isDownloadingUpdate = false

            if (ok && outFile.exists()) {
                updateProgressBar.progress = 100
                updateStatusText.text = "Запуск установщика Android..."
                btnUpdateNow.isEnabled = true
                btnUpdateNow.text = "Установить обновление"
                launchApkInstaller(outFile)
            } else {
                updateStatusText.text = "Не удалось скачать автоматически — попробуйте ещё раз или через браузер"
                btnUpdateNow.isEnabled = true
                btnUpdateNow.text = "Повторить загрузку"
                btnUpdateBrowser.visibility = View.VISIBLE
            }
        }
    }

    private fun launchApkInstaller(apkFile: File) {
        try {
            val apkUri = FileProvider.getUriForFile(
                this,
                "${BuildConfig.APPLICATION_ID}.fileprovider",
                apkFile
            )
            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(apkUri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(installIntent)
        } catch (_: Exception) {
            activeUpdateInfo?.apkUrl?.let { openExternalUri(Uri.parse(it)) }
        }
    }
}
