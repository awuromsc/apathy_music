package dev.apathy.player

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

data class AppVersionInfo(
    val latestVersionCode: Int,
    val latestVersionName: String,
    val minVersionCode: Int,
    val force: Boolean,
    val apkUrl: String,
    val changelog: String
)

object UpdateChecker {

    suspend fun fetchVersionInfo(apiUrl: String): AppVersionInfo? = withContext(Dispatchers.IO) {
        var conn: HttpURLConnection? = null
        try {
            val url = URL("$apiUrl?_=${System.currentTimeMillis()}")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 5000
                readTimeout = 5000
                setRequestProperty("Accept", "application/json")
            }
            if (conn.responseCode != 200) return@withContext null
            val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val json = JSONObject(body)
            if (!json.optBoolean("ok", false)) return@withContext null

            val latestCode = json.optInt("latestVersionCode", 1)
            val latestName = json.optString("latestVersionName", "1.0.0")
            val minCode = json.optInt("minVersionCode", 1)
            val forceFlag = json.optBoolean("force", false)
            val apkUrl = json.optString("apkUrl", "").trim()
            val changelog = json.optString("changelog", "Улучшения стабильности и новые функции.")

            AppVersionInfo(
                latestVersionCode = latestCode,
                latestVersionName = latestName,
                minVersionCode = minCode,
                force = forceFlag,
                apkUrl = apkUrl,
                changelog = changelog
            )
        } catch (_: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    suspend fun downloadApk(
        apkUrl: String,
        targetFile: File,
        onProgress: (percent: Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        var conn: HttpURLConnection? = null
        try {
            var currentUrl = apkUrl
            var redirects = 0
            while (redirects < 6) {
                conn = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = false
                    connectTimeout = 12000
                    readTimeout = 30000
                    setRequestProperty("User-Agent", "APATHY-Android/${BuildConfig.VERSION_NAME}")
                }
                val code = conn.responseCode
                if (code in 301..308) {
                    val loc = conn.getHeaderField("Location") ?: break
                    currentUrl = URL(URL(currentUrl), loc).toString()
                    conn.disconnect()
                    redirects++
                    continue
                }
                break
            }
            val activeConn = conn ?: return@withContext false
            if (activeConn.responseCode !in 200..299) return@withContext false

            val total = activeConn.contentLengthLong
            val tmpFile = File(targetFile.parentFile, targetFile.name + ".part")
            if (tmpFile.exists()) tmpFile.delete()

            activeConn.inputStream.use { input ->
                FileOutputStream(tmpFile).use { output ->
                    val buf = ByteArray(16384)
                    var downloaded = 0L
                    var lastPct = -1
                    while (true) {
                        val n = input.read(buf)
                        if (n <= 0) break
                        output.write(buf, 0, n)
                        downloaded += n
                        if (total > 0) {
                            val pct = ((downloaded * 100L) / total).toInt().coerceIn(0, 100)
                            if (pct != lastPct) {
                                lastPct = pct
                                withContext(Dispatchers.Main) { onProgress(pct) }
                            }
                        }
                    }
                    output.flush()
                }
            }

            if (tmpFile.length() < 50_000L) {
                tmpFile.delete()
                return@withContext false
            }
            if (targetFile.exists()) targetFile.delete()
            tmpFile.renameTo(targetFile)
        } catch (_: Exception) {
            false
        } finally {
            conn?.disconnect()
        }
    }
}
