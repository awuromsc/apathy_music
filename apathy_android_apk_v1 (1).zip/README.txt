APATHY Android APK (Kotlin WebView + Force Update)
==================================================

ВОЗМОЖНОСТИ ПРИЛОЖЕНИЯ:
1. Открывает https://awuro.sergeyhownan.workers.dev/ на весь экран в тёмном стиле без рамок браузера.
2. Поддерживает вход через Telegram (t.me / window.open), переход в канал https://t.me/apathymsc,
   загрузку своих MP3/M4A и смену фото профиля, оффлайн-кэш (IndexedDB + Service Worker).
3. Фоновое воспроизведение музыки при сворачивании и выключении экрана (AudioKeepAliveService).
4. Принудительное и обычное обновление (Force Update):
   - При запуске запрашивает https://bot-1795701331-3932-awuro.bothost.tech/api/app/version
   - Если versionCode < minVersionCode -> блокирует приложение тёмным экраном обновления,
     скачивает свежий .apk с прогресс-баром и сразу запускает установку на Android.

КАК СОБРАТЬ .APK БЕЗ ANDROID STUDIO (ЗА 3 МИНУТЫ НА GITHUB):
1. Создайте новый пустой репозиторий на GitHub (например, apathy-android) и загрузите в него
   все файлы из архива apathy_android_apk_v1.zip (включая папку .github/workflows/build-apk.yml).
2. Откройте вкладку Actions -> Build APATHY Android APK -> дождитесь зелёной галочки (2-3 мин).
3. Скачайте два артефакта внизу страницы сборки:
   - APATHY-APK-v1.0.0 -> внутри готовый установочный файл APATHY-v1.0.0-c1.apk!
   - SAVE-THIS-KEYSTORE-FOR-UPDATES -> внутри файл KEYSTORE_BASE64.txt.
4. ОДИН РАЗ сохраните ключ подписи для будущих обновлений:
   GitHub -> Settings -> Secrets and variables -> Actions -> New repository secret:
   - Name: KEYSTORE_BASE64
   - Value: вставьте содержимое файла KEYSTORE_BASE64.txt
   (Это гарантирует, что версии v2, v3... установятся поверх v1 без удаления приложения и потери кэша!)

КАК ВЫПУСТИТЬ ОБНОВЛЕНИЕ И ЗАСТАВИТЬ ПОЛЬЗОВАТЕЛЕЙ ОБНОВИТЬСЯ:
1. В GitHub -> Actions -> Build APATHY Android APK -> Run workflow:
   укажите version_code = 2, version_name = 1.1.0 -> скачайте новый APK.
2. Отправьте новый .apk файл прямо в личку вашего Telegram-бота (с админ-аккаунта) — бот сам
   сохранит файл и раздаст его по /api/app/download и команде /apk.
3. Напишите боту:
   /setapp 2 2 1.1.0 | Новые функции и исправления
   (где первая цифра — последняя версия, вторая — минимально допустимая. Если они равны,
   у всех пользователей на v1 сразу появится обязательный экран обновления!)
